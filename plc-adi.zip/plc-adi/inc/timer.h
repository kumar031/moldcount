/*
 * timer.h
 */

#ifndef __TIMER_H__
#define __TIMER_H__

#include "common.h"

typedef enum timer_event_t {
  TIMER_EVENT_NONE,
  TIMER_EVENT_PTM_FREQUENCY_TRIGGERED,
  TIMER_EVENT_PERSIST_FREQUENCY_TRIGGERED
} timer_event_t;

uint8_t timer_init(uint32_t conf_ptm_sync_frequency,
    uint32_t conf_persist_sync_frequency,
    uint8_t (*timer_event_callback)(timer_event_t event));
uint8_t timer_loop(void);
uint8_t timer_deinit(void);

#endif // __TIMER_H__
