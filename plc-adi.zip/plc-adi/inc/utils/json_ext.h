/*
 * json_ext.h
 */

#ifndef __JSON_EXT_H__
#define __JSON_EXT_H__

#include "common.h"
#include "core_json.h"

/* Usage:
 *
 * char * jsonstr = "{"foo":11,"bar":{"foo":"xyz"}}";
 *
 * char strval[10];
 * uint8_t err = getjsonstr(jsonstr, "bar.foo", strval, sizeof(strval));
 * // if !err then 'strval' now contains null terminated "xyz" ('x', 'y', 'z', '\0')
 *
 * long lval;
 * uint8_t err = getjsonlong(jsonstr, "foo", lval);
 * // if !err then 'lval' now contains 11 of type 'long'
 */

/* Returns null terminated character string in pre-allocated 'p_out_str' of size 'out_str_maxlen'
 * Before using this function:
 *   It is must to validate passed 'jsonstr' via 'JSON_Validate()' once (return status must be 'JSONSuccess')
 *   'out_str_maxlen' must be 1 less then 'JSON_EXT_STR_VALUE_MAXLEN' to store null character also
 */
uint8_t readjson_str(char * jsonstr, const char * querystr, char * p_out_str,
    size_t out_str_maxlen);

/* Returns integer in pre-allocated long type 'p_out_long'
 * Before using this function:
 *   It is must to validate passed 'jsonstr' via 'JSON_Validate()' once (return status must be 'JSONSuccess')
 */
uint8_t readjson_long(char * jsonstr, const char * querystr, long * p_out_long);

/*
 * other integer declarations
 */
#define readjson_uint32(jsonstr, querystr, p_out_uint32) readjson_long(jsonstr, querystr, (long*)p_out_uint32)
#define readjson_int32 (jsonstr, querystr, p_out_int32)  readjson_uint32(jsonstr, querystr, p_out_int32)
#define readjson_uint16(jsonstr, querystr, p_out_uint16) readjson_uint32(jsonstr, querystr, p_out_uint16)
#define readjson_int16 (jsonstr, querystr, p_out_int16)  readjson_uint32(jsonstr, querystr, p_out_int16)
#define readjson_uint8 (jsonstr, querystr, p_out_uint8)  readjson_uint32(jsonstr, querystr, p_out_uint8)
#define readjson_int8  (jsonstr, querystr, p_out_int8)   readjson_uint32(jsonstr, querystr, p_out_int8)

#endif // __JSON_EXT_H__
