/*
 * cqueue.h
 */

#ifndef __CQUEUE_H__
#define __CQUEUE_H__

#include "common.h"

typedef struct cqueue_t {
  uint8_t * items_buf;     // base address used for the items in the queue
  uint32_t max_itemcount;  // maximum count of items in the queue
  uint32_t itemcount;      // count of items exists in current queue that can be dequeued
  size_t itemsize;         // size of an item in the queue
  uint8_t * front;         // points to the earliest item in the queue
  uint8_t * rear;          // points to the latest item in the queue
} cqueue_t;

// initqueue(): Initializes 'cqptr' and sets already allocated 'items_buf' into
//     it as queue buffer
//   Values of 'max_itemcount' and 'itemsize' should be 1 or more
//   Returns 0 if no error and other value if error
uint8_t initqueue(cqueue_t * cqptr, void * items_buf, uint32_t max_itemcount,
    size_t itemsize);

// enqueue(): Enqueues an 'item' into already initialized 'cqptr'
//   If queue is full then discards oldest item and writes new item there
//   Returns 0 if no error and other value if error
uint8_t enqueue(cqueue_t * cqptr, void * item);

// dequeue(): Dequeues an 'item' from already initialized 'cqptr'
//     A call with 'item' as NULL is assumed that no copy is required before
//       removing the 'item' from queue
//   Returns 0 if no error and other value if error
uint8_t dequeue(cqueue_t * cqptr, void * item);

// getqueuenextitemptr(): Returns next possible item pointer from cqptr
//   This macro directly uses 'get_next_cqitemptr'. Its like a replica of
//     'get_next_cqitemptr', and made just to match other queue apt patterns
#define getqueuenextitemptr(cqptr, itemptr)  \
  get_next_cqitemptr((cqptr), (itemptr))

// getqueuenextitemptr(): Returns next possible item pointer from cqptr
uint8_t * get_next_cqitemptr(const cqueue_t * cqptr, const uint8_t * itemptr);

// isqueueempty(): Returns true if queue is empty
#define isqueueempty(cqptr)  (!(cqptr) && !((cqptr)->front))

// isqueuefull(): Returns true if queue is full
#define isqueuefull(cqptr)  \
  ((cqptr) && ((cqptr)->itemcount == (cqptr)->max_itemcount))

// getqueuefront(): Returns pointer to the earliest item in the queue
//   (i.e. front of queue)
#define getqueuefront(cqptr)  ((void*) ((cqptr) ? ((cqptr)->front) : NULL))

// getqueuecount(): return count of total items in the queue
#define getqueuecount(cqptr)  ((cqptr) ? ((cqptr)->itemcount) : 0)

#endif // __CQUEUE_H__
