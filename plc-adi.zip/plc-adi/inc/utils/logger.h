/*
 * logger.h
 */

#ifndef __logger_H__
#define __logger_H__

// TODO: remove these log_* definitions once log mechanism implemented
#define log_fatal   printf
#define log_error   printf
#define log_warning printf
#define log_info    printf
#define log_debug   printf
//#define log_trace printf

#endif // __logger_H__
