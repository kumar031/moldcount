/*
 * plc.h
 */

#ifndef __PLC_H__
#define __PLC_H__

#include "common.h"

typedef enum plc_event_t {
  PLC_EVENT_NONE,
  PLC_EVENT_BUTTON_PUSHED,
  PLC_EVENT_BUTTON_RELEASED,
  PLC_EVENT_POWER_OFF
} plc_event_t;

uint8_t plc_init(uint8_t (*plc_event_callback)(plc_event_t event));
uint8_t plc_loop(void);
uint8_t plc_deinit(void);

#endif // __PLC_H__
