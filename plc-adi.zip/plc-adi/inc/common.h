/*
 * common.h
 */

#ifndef __COMMON_H__
#define __COMMON_H__

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#endif // __COMMON_H__
