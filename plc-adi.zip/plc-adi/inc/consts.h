/*
 * consts.h
 */

#ifndef __CONSTS_H__
#define __CONSTS_H__

#define PTM_MSG_VERSION  0x01  // PTM's iot message protocol version

#define DEVICE_IDENTIFIER                        "zmx-mold-00000001"
//#define DEVICE_IDENTIFIER_MAXLEN                 (20)

#define PERSISTED_RCR_MAXCOUNT                   (50)     // Maximum count of RCR that can be persisted
#define PERSISTED_CYCLETIMES_MAXCOUNT            (10000)  // Maximum count of cycle times that can be persisted

// configuration file path
#define FS_CONFFILE_PATH  \
  "./config/config.json"

#define FS_CONFFILE_MAXSIZE                      (1024)

#define FS_FILEPATH_MAXLEN                       (255)  // Maximum filepath length

#define JSON_EXT_STR_VALUE_MAXLEN                (FS_FILEPATH_MAXLEN + 1)

// NOTE: only single digit 'NLAST_CYCLETIMES_TOAVG_ARRSIZE' is supported for now
#define NLAST_CYCLETIMES_TOAVG_ARRSIZE           (3)   // Maximum array size each element holds count of last n cycle time to average
#if (NLAST_CYCLETIMES_TOAVG_ARRSIZE > 9)
#error "Only single digit 'NLAST_CYCLETIMES_TOAVG_ARRSIZE' is supported for now."
#endif

/*--------------------------------------------------------------------------*/

#define IOT_ENDPOINT_MAXLEN                      (64)  // Maximum length of IoT endpoint
#define IOT_TOPIC_MAXLEN                         (128) // Maximum length of IoT topic
#define IOT_SHADOWNAME_MAXLEN                    (20)  // Maximum length of IoT shadow name
#define AWS_MQTT_PORT                            (443)
#define MAX_OUTGOING_PUBLISHES                   (5U)
#define CONNECTION_RETRY_BACKOFF_BASE_MS         (500U)
#define CONNECTION_RETRY_MAX_BACKOFF_DELAY_MS    (5000U)
#define CONNECTION_RETRY_MAX_ATTEMPTS            (5U)
#define TRANSPORT_SEND_RECV_TIMEOUT_MS           (500)
#define MQTT_PROCESS_LOOP_TIMEOUT_MS             (1000U)
#define MQTT_KEEP_ALIVE_INTERVAL_SECONDS         (60U)
#define CONNACK_RECV_TIMEOUT_MS                  (1000U)
#define NETWORK_BUFFER_SIZE                      (1024U)

/*--------------------------------------------------------------------------*/

#define IOT_TOPIC_UPDATE_FMT                     "$aws/things/%s/shadow/name/%s/update"
#define IOT_TOPIC_UPDATE_ACCEPTED_FMT            "$aws/things/%s/shadow/name/%s/update/accepted"
#define IOT_TOPIC_UPDATE_REJECTED_FMT            "$aws/things/%s/shadow/name/%s/update/rejected"

/*--------------------------------------------------------------------------*/

//Sample PTM/RTM json:
//  {"ts":0,"msgType":2,"msgVersion":1,"cycleCount":13072,"cycleTimeAvgL1HB":3,"cycleTimeAvgL10HB":4,"cycleTimeAvgL100HB":2}

#define SERVER_RCR_JSON_MAX_SIZE                 (512)

#define SERVER_RCR_JSON_FMT  "{\"state\":{\"reported\":{\"deviceId\":\"%s\",\
  \"ts\":%ld,\"msgType\":%u,\"msgVersion\":%u,\"cycleCount\":%u,\
  \"cycleTimeAvgL1HB\":%u,\"cycleTimeAvgL10HB\":%u,\"cycleTimeAvgL100HB\":%u}}}"

#endif // __CONSTS_H__
