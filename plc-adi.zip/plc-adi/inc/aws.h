/*
 * aws.h
 */

#ifndef __AWS_H__
#define __AWS_H__

#include "common.h"

typedef enum aws_event_t {
  AWS_EVENT_NONE,
  AWS_EVENT_IOT_RCR_RESPONSE_ACCEPTED,
  AWS_EVENT_IOT_RCR_RESPONSE_REJECTED
} aws_event_t;

uint8_t aws_init(uint8_t (*aws_event_callback)(aws_event_t event),
    const char * endpoint, const char * rootca_path, const char * cert_path,
    const char * key_path);
uint8_t aws_loop(void);
uint8_t aws_deinit(void);

uint8_t publish_to_topic(const char * topic, const uint8_t * payload,
    size_t payload_len);
uint8_t subscribe_to_topic(const char * topic);
uint8_t unsubscribe_from_topic(const char * topic);

#endif // __AWS_H__
