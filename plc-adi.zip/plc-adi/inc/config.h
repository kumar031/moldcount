/*
 * config.h
 */

#ifndef __CONFIG_H__
#define __CONFIG_H__

#include "common.h"
#include "consts.h"

// IoT configuration type
typedef struct config_iot_t {
  char endpoint[IOT_ENDPOINT_MAXLEN];
  char shadow_name[IOT_SHADOWNAME_MAXLEN];
  char rootca_path[FS_FILEPATH_MAXLEN];
  char cert_path[FS_FILEPATH_MAXLEN];
  char key_path[FS_FILEPATH_MAXLEN];
} config_iot_t;

// PTM configuration type
typedef struct config_ptm_t {
  uint32_t sync_frequency;
  uint32_t nlastcycletimes_toavg[NLAST_CYCLETIMES_TOAVG_ARRSIZE];
} config_ptm_t;

// Persist configuration type
typedef struct config_persist_t {
  uint32_t sync_frequency;
  //char rcr_cq_path[FS_FILEPATH_MAXLEN];
  //char cycletime_cq_path[FS_FILEPATH_MAXLEN];
} config_persist_t;

// Configuration type
typedef struct config_t {
  struct config_iot_t iot;
  struct config_ptm_t ptm;
  struct config_persist_t persist;
} config_t;

uint8_t load_configurations(config_t * const config);
//uint8_t save_configurations(config_t * const config);

#endif // __CONFIG_H__
