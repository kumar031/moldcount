/*
 * data.h
 */

#ifndef __DATA_H__
#define __DATA_H__

#include "common.h"
#include "consts.h"
#include <time.h>

// TODO: move 'report_iot_msg_type_t' to some iot related file
// IOT message type for reporting
typedef enum report_iot_msg_type_t {
  REPORT_IOT_MSG_TYPE_INVALID = 0x00,  // Invalid Message Type
  REPORT_IOT_MSG_TYPE_RTM     = 0x01,  // Realtime Telemetry Message Type
  REPORT_IOT_MSG_TYPE_PTM     = 0x02,  // Periodic Telemetry Message Type
  REPORT_IOT_MSG_TYPE_PIM     = 0x03,  // Periodic Inspection Message Type
  REPORT_IOT_MSG_TYPE_SEM     = 0x04,  // System Event Message Type
  REPORT_IOT_MSG_TYPE_ODM     = 0x05   // On-demand Diagnostics Message Type
} report_iot_msg_type_t;

// Remote Condition Record type
typedef struct rcr_t {
  time_t timestamp;
  report_iot_msg_type_t msg_type;
  uint8_t msg_version;
  uint32_t cycle_count;
  uint32_t avg_cycletimes[NLAST_CYCLETIMES_TOAVG_ARRSIZE];
} rcr_t;

uint8_t data_init(const uint32_t * conf_ptm_nlastcycletimes_toavg,
    const char * iot_topic_rcr, uint8_t (*publish_to_topic)(
      const char * iot_topic, const uint8_t * payload, size_t payload_len));
uint8_t data_loop(void);
uint8_t data_deinit(void);

void set_report_iot_msg_type(report_iot_msg_type_t msg_type);
uint8_t add_mold_data(time_t timestamp, uint32_t new_cycletime);
void activate_ptm_transactions(void);
void iot_rcr_act_on_response(bool isaccepted);

#endif // __DATA_H__
