/*
 * plc.c
 */

#include "plc.h"
#include "logger.h"

#if 1
#include "dal/adi_application_interface.h"
#include <sched.h>
#include <string.h>

#define KBUS_MAINPRIO  40
#define isactive_plc_io_state(data, state)  ((data & state) == state)

typedef enum plc_io_state_t {
  PLC_IO_STATE_POWER_OFF     = 0x01,
  PLC_IO_STATE_BUTTON_PUSHED = 0x02
} plc_io_state_t;

// internal member definitions
static struct {
  tApplicationDeviceInterface * adi;
  tDeviceId kbusDeviceId;
  bool is_button_push_holded;
  uint8_t (*plc_event_callback)(plc_event_t event);
} plc = { 0 };

static inline uint8_t read_plc_io_data(uint8_t * io_data, tDeviceId * const pDev,
    uint32_t * const pTid, tApplicationDeviceInterface * pAdi)
{
  uint8_t err = 0;

  if (io_data) {
    uint8_t data;

    pAdi->ReadStart(*pDev, *pTid);
    pAdi->ReadBytes(*pDev, *pTid, 0, 1, (uint8_t *) &data);
    pAdi->ReadEnd(*pDev, *pTid);

    if (!err) {
      *io_data = data;
    }

    log_debug("IO data=%d\t", data);
  } else {
    err = 1;
    log_error("'io_data' passed as null");
  }
  return err;
}

uint8_t plc_init(uint8_t (*plc_event_callback)(plc_event_t event)) {
  uint8_t err = 0;

  tDeviceInfo deviceList[10];
  tApplicationStateChangedEvent event;
  size_t nrDevicesFound;
  size_t nrKbusFound;
  struct sched_param s_param;

  // local attribute initialization
  plc.adi = NULL;
  plc.is_button_push_holded = false;
  plc.plc_event_callback = NULL;

  plc.adi = adi_GetApplicationInterface();
  if (plc.adi == NULL) {
    log_fatal("adi_GetApplicationInterface failed\n");
    err = 4;
  }

  if (!err) {
    plc.adi->Init();
    plc.adi->ScanDevices();
    plc.adi->GetDeviceList(sizeof(deviceList), deviceList, &nrDevicesFound);

    nrKbusFound = (size_t)-1;
    for (uint32_t i = 0; i < nrDevicesFound; ++i) {
      if (strcmp(deviceList[i].DeviceName, "libpackbus") == 0) {
        nrKbusFound = i;
        log_info("KBUS device found as device %i\n", i);
      }
    }

    if (nrKbusFound == (size_t)-1) {
      log_fatal("No KBUS device found\n");

      plc.adi->Exit();
      err = 1;
    }
  }

  if (!err) {
    s_param.sched_priority = KBUS_MAINPRIO;
    sched_setscheduler(0, SCHED_FIFO, &s_param);
    plc.kbusDeviceId = deviceList[nrKbusFound].DeviceId;
    if (plc.adi->OpenDevice(plc.kbusDeviceId) != DAL_SUCCESS) {
      log_fatal("Kbus device open failed\n");

      plc.adi->Exit();
      err = 2;
    }
  }

  if (!err) {
    event.State = ApplicationState_Running;
    if (plc.adi->ApplicationStateChanged(event) != DAL_SUCCESS) {
      log_fatal("Set application state to 'Running' failed\n");

      plc.adi->CloseDevice(plc.kbusDeviceId);
      plc.adi->Exit();
      err = 3;
    }
  }

  if (!err) {
    plc.plc_event_callback = plc_event_callback;
  }

  return err;
}

uint8_t plc_loop(void) {
  uint8_t err = 0;
  uint32_t retval = 0;

  if (plc.adi) {
    plc.adi->WatchdogTrigger();
  } else {
    log_fatal("adi is null\n");
    err = 1;
  }

  if (!err && (plc.adi->CallDeviceSpecificFunction("libpackbus_Push", &retval) != DAL_SUCCESS)) {
    log_fatal("CallDeviceSpecificFunction failed\n");
    err = 8;  // TODO: could place plc_event instead and then callback?
  }

  if (!err && (retval != DAL_SUCCESS)) {
    log_fatal("Function 'libpackbus_Push' failed\n");
    err = 9;  // TODO: could place plc_event instead and then callback?
  }

  if (!err) {
    uint8_t io_data = 0;
    uint32_t taskId = 0;

    err = read_plc_io_data(&io_data, &plc.kbusDeviceId, &taskId, plc.adi);

    if (!err) {
      plc_event_t plc_event = PLC_EVENT_NONE;

      // TODO: logical error: handle if multiple i.e. 'PLC_EVENT_*' events happened at same time

      if (isactive_plc_io_state(io_data, PLC_IO_STATE_BUTTON_PUSHED)) {
        if (!plc.is_button_push_holded) {
          plc.is_button_push_holded = true;
          plc_event = PLC_EVENT_BUTTON_PUSHED;
        }
      } else {
        if (plc.is_button_push_holded) {
          plc.is_button_push_holded = false;
          plc_event = PLC_EVENT_BUTTON_RELEASED;
        }
      }

      if (isactive_plc_io_state(io_data, PLC_IO_STATE_POWER_OFF)) {
        plc_event = PLC_EVENT_POWER_OFF;
      }

      if ((plc_event != PLC_EVENT_NONE) && plc.plc_event_callback) {
        err = plc.plc_event_callback(plc_event);
      }
    }
  }

  return err;
}

uint8_t plc_deinit(void) {
  // TODO: check for error handling
  plc.adi->CloseDevice(plc.kbusDeviceId);
  plc.adi->Exit();
  return 0;
}
#else
uint8_t init_plc(uint8_t (*plc_event_callback)(plc_event_t event)) {
  return 0;
}
uint8_t plc_loop(void) {
  return 0;
}
uint8_t deinit_plc(void) {
  return 0;
}
#endif
