/*
 * moldRCMS.c
 */

#include "config.h"
#include "logger.h"
#include "plc.h"
#include "data.h"
#include "aws.h"
#include "timer.h"
#include <unistd.h>
#include <time.h>

// TODO: decide below callbacks actully required or not

static uint8_t plc_event_callback(plc_event_t event) {
  static time_t cycle_start_time = 0;
  time_t curr_time = 0;

  curr_time = time(NULL);

  switch(event) {
    case PLC_EVENT_POWER_OFF:
      log_debug("\nPLC Power-off event received\n");
      // handle power down
      break;

    case PLC_EVENT_BUTTON_PUSHED:
      cycle_start_time = curr_time;
      log_debug("\nPLC Button-pressed event received\n");
      break;

    case PLC_EVENT_BUTTON_RELEASED:
      // TODO: for better time tracking calculating cycle time can be done inside 'plc_loop()' itself
      // calculate cycle time and update mold data
      add_mold_data(curr_time, (curr_time - cycle_start_time));
      log_debug("\nPLC Button-released event received\n");
      break;

    case PLC_EVENT_NONE:
    default:
      log_error("\nUnhandled PLC event received\n");
      break;
  }

  return 0;
}

static uint8_t timer_event_callback(timer_event_t event) {
  switch(event) {
    case TIMER_EVENT_PTM_FREQUENCY_TRIGGERED:
      log_debug("TImer PTM frequency triggered event received\n");
      // send collected rcr to server
      // first check for persistent data and then from RAM
      activate_ptm_transactions();
      break;

    case TIMER_EVENT_PERSIST_FREQUENCY_TRIGGERED:
      log_debug("TImer Persistent-Sync frequency triggered event received\n");
      // TODO: what's the need
      // if storing at frequency then ptm_frequency case will
      //   consume more time
      break;

    case TIMER_EVENT_NONE:
    default:
      log_error("Unhandled PLC event received\n");
      break;
  }

  return 0;
}

static uint8_t aws_event_callback(aws_event_t event) {
  switch(event) {
    case AWS_EVENT_IOT_RCR_RESPONSE_ACCEPTED:
      log_debug("AWS RCR response accepted event received\n");
      iot_rcr_act_on_response(true);
      break;
    case AWS_EVENT_IOT_RCR_RESPONSE_REJECTED:
      log_debug("AWS RCR response rejected event received\n");
      iot_rcr_act_on_response(false);
      break;
      break;
    case AWS_EVENT_NONE:
    default:
      log_error("Unhandled aws_event_t\n");
      break;
  }

  return 0;
}

// TODO: proper error handling need to be done
int main(void) {
  uint8_t err = 0;
  config_t config = { 0 };
  char topic_shadow_upd[IOT_TOPIC_MAXLEN] = "";
  char topic_shadow_upd_acc[IOT_TOPIC_MAXLEN] = "";
  char topic_shadow_upd_rej[IOT_TOPIC_MAXLEN] = "";

  err = load_configurations(&config);

  if (!err) {
    snprintf(topic_shadow_upd, sizeof(topic_shadow_upd),
        IOT_TOPIC_UPDATE_FMT, DEVICE_IDENTIFIER, config.iot.shadow_name);
    snprintf(topic_shadow_upd_acc, sizeof(topic_shadow_upd_acc),
        IOT_TOPIC_UPDATE_ACCEPTED_FMT, DEVICE_IDENTIFIER, config.iot.shadow_name);
    snprintf(topic_shadow_upd_rej, sizeof(topic_shadow_upd_rej),
        IOT_TOPIC_UPDATE_REJECTED_FMT, DEVICE_IDENTIFIER, config.iot.shadow_name);
  }

  // initialize various components
  if (!err) {
    err = data_init(config.ptm.nlastcycletimes_toavg,
        topic_shadow_upd, &publish_to_topic);
    if (!err) {
      set_report_iot_msg_type((config.ptm.sync_frequency ? REPORT_IOT_MSG_TYPE_PTM :
            REPORT_IOT_MSG_TYPE_RTM));
    }
  }

  if (!err) {
    err = plc_init(&plc_event_callback);
  }

  if (!err) {
    err = aws_init(&aws_event_callback, config.iot.endpoint,
        config.iot.rootca_path, config.iot.cert_path, config.iot.key_path);
    if (!err) {
      err = subscribe_to_topic(topic_shadow_upd_acc);
      err = subscribe_to_topic(topic_shadow_upd_rej);
    }
  }

  if (!err) {
    err = timer_init(config.ptm.sync_frequency,
        config.persist.sync_frequency, &timer_event_callback);
    //// timer_start();
    //// set_timer(callback); // priority queue
  }

  // forever loop
  // NOTE: no function should consume much time in this loop
  // TODO: try to put timeouts for each component functions
  for( ; ; ) {
    plc_loop();
    timer_loop();
    data_loop();
    aws_loop();

    usleep(10000);
  }

  // program must never reach here
  log_fatal("Program control MUST NOT reach here.\n");

  // deinitialize various components
  // timer_deinit();
  // plc_deinit();
  // unsubscribe_to_topic(topic_shadow_upd_acc);
  // unsubscribe_to_topic(topic_shadow_upd_rej);
  // aws_deinit();
  // data_deinit();
  return 0;
}
