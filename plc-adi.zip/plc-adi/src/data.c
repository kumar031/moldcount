/*
 * data.c
 */

#include "data.h"
#include "logger.h"
#include "cqueue.h"
#include <string.h>

typedef enum iot_state_t {
  IOT_STATE_IDLE,
  IOT_STATE_RCR_PREPARE_NEXT,
  IOT_STATE_RCR_READY_TO_SEND,
  IOT_STATE_RCR_RESPONSE_WAITING,
  IOT_STATE_RCR_RESPONSE_SUCCESS,
  IOT_STATE_RCR_RESPONSE_FAILED,
  //IOT_STATE_RCR_RESPONSE_TIMEOUT
} iot_state_t;

// internal member definitions
static struct {
  uint32_t cycle_count;
  uint32_t cycle_time;
  uint32_t sum_lastn_cycletimes[NLAST_CYCLETIMES_TOAVG_ARRSIZE];
  uint32_t cycletimes[PERSISTED_CYCLETIMES_MAXCOUNT];
  rcr_t rcrs[PERSISTED_RCR_MAXCOUNT];
  cqueue_t cycletimecq;
  cqueue_t rcrcq;
} data_persisted = { 0 };

static struct {
  uint32_t conf_ptm_nlastcycletimes_toavg[NLAST_CYCLETIMES_TOAVG_ARRSIZE];
  uint8_t * queuefront_lastn_cycletimes[NLAST_CYCLETIMES_TOAVG_ARRSIZE];
  report_iot_msg_type_t report_iot_msg_type;
  iot_state_t iot_state;
  bool ptm_transactions_activated;
  char rcrjson[SERVER_RCR_JSON_MAX_SIZE];
  char iot_topic_rcr[IOT_TOPIC_MAXLEN];
  uint8_t (*publish_to_topic)(const char * iot_topic, const uint8_t * payload,
      size_t payload_len);
} data = { 0 };

static inline uint8_t get_avg_lastn_cycletimes(uint32_t * avg_lastn_cycletimes,
    uint8_t index) {
  uint8_t err = 0;
  uint32_t queueCount = getqueuecount(&data_persisted.cycletimecq);

  if (index < NLAST_CYCLETIMES_TOAVG_ARRSIZE) {
    // calculate rounded average
    if (queueCount < data.conf_ptm_nlastcycletimes_toavg[index]){
      *avg_lastn_cycletimes = ((float)data_persisted.sum_lastn_cycletimes[index] /
          queueCount) + 0.5;
    } else {
      *avg_lastn_cycletimes = ((float)data_persisted.sum_lastn_cycletimes[index] /
          data.conf_ptm_nlastcycletimes_toavg[index]) + 0.5;
    }
  } else {
    log_error("Unhandled index to get average of last n cycle times\n");
    err = 1;
  }

  return err;
}

static inline uint8_t prepare_rcrjson(char * rcrjson,
    size_t rcrjson_bufsize, const rcr_t * rcr) {
  uint8_t err = 0;

  if (rcr && rcrjson && rcrjson_bufsize) {
    // prepare JSON for the fetched RCR
    snprintf (rcrjson, rcrjson_bufsize, SERVER_RCR_JSON_FMT, DEVICE_IDENTIFIER,
        rcr->timestamp, rcr->msg_type, PTM_MSG_VERSION, rcr->cycle_count,
        rcr->avg_cycletimes[0], rcr->avg_cycletimes[1], rcr->avg_cycletimes[2]);
  } else {
    err = 1;
  }

  return err;
}

uint8_t data_init(const uint32_t * conf_ptm_nlastcycletimes_toavg,
    const char * iot_topic_rcr, uint8_t (*publish_to_topic)(
      const char * iot_topic, const uint8_t * payload, size_t payload_len)) {
  uint8_t err = 0;

  // local attribute initialization
  data_persisted.cycle_count = 0;
  data_persisted.cycle_time = 0;

  for (uint8_t i = 0; (!err && (i < NLAST_CYCLETIMES_TOAVG_ARRSIZE)); ++i) {
    if (conf_ptm_nlastcycletimes_toavg[i] > PERSISTED_CYCLETIMES_MAXCOUNT) {
      log_fatal("init failed: conf_ptm_nlastcycletimes_toavg[%u] is greater than PERSISTED_CYCLETIMES_MAXCOUNT", i);
      err = 1;
    }

    data.conf_ptm_nlastcycletimes_toavg[i] = conf_ptm_nlastcycletimes_toavg[i];
    data_persisted.sum_lastn_cycletimes[i] = 0;
  }

  if (!err) {
    data.report_iot_msg_type = REPORT_IOT_MSG_TYPE_INVALID;
    memcpy(data.iot_topic_rcr, iot_topic_rcr, strlen(iot_topic_rcr));
    data.publish_to_topic = publish_to_topic;

    initqueue(&data_persisted.cycletimecq, data_persisted.cycletimes,
        (sizeof(data_persisted.cycletimes)/sizeof(*data_persisted.cycletimes)),
        sizeof(*data_persisted.cycletimes));
    initqueue(&data_persisted.rcrcq, data_persisted.rcrs,
        (sizeof(data_persisted.rcrs)/sizeof(*data_persisted.rcrs)),
        sizeof(*data_persisted.rcrs));

    //err = persist_load_data(&data_persisted);
  }

  return err;
}

uint8_t data_loop(void) {
  uint8_t err = 0;
  bool loop = true;

  while (loop) {
    loop = false;

    log_debug("IOT_STATE_%d\n", data.iot_state);

    switch (data.iot_state) {
      case IOT_STATE_IDLE:
        if (data.ptm_transactions_activated) {
          data.iot_state = IOT_STATE_RCR_PREPARE_NEXT;
          loop = true;
        }
        break;
      case IOT_STATE_RCR_PREPARE_NEXT:
        // fetch oldest RCR from queue and prepare rcrjson for it
        err = prepare_rcrjson(data.rcrjson, SERVER_RCR_JSON_MAX_SIZE,
            getqueuefront(&data_persisted.rcrcq));

        if (!err) {
          data.iot_state = IOT_STATE_RCR_READY_TO_SEND;
          loop = true;
        } else {
          data.ptm_transactions_activated = false;
          data.iot_state = IOT_STATE_IDLE;
        }
        break;
      case IOT_STATE_RCR_READY_TO_SEND:
        // send RCR to server
        err = data.publish_to_topic(data.iot_topic_rcr, (uint8_t *)data.rcrjson,
            strlen(data.rcrjson));

        if (!err) {
          data.iot_state = IOT_STATE_RCR_RESPONSE_WAITING;
          log_info("RCR sent to server successfully\n");
        } else {
          log_warning("Sending RCR to server get failed\n");
        }
        break;
      case IOT_STATE_RCR_RESPONSE_WAITING:
        // nothing to do just wait for response
        // iot_rcr_response_callback() will update iot_state further

        // TODO: set timeout logic here
        // if (timeout) {
        //   data.iot_state = IOT_STATE_RCR_RESPONSE_TIMEOUT;
        // }

        // TODO: also need to cover scenarios to cancel ongoing activity or
        // any other scenario like anything important needs to be done
        break;
      case IOT_STATE_RCR_RESPONSE_SUCCESS:
        log_info("Sent RCR is successfully updated at server\n");
        dequeue(&data_persisted.rcrcq, NULL);
        // TODO: check here if want to exit in-between; just not to spent much time
        // check timout or cancel loop
        data.iot_state = IOT_STATE_RCR_PREPARE_NEXT;
        loop = true;
        break;
      case IOT_STATE_RCR_RESPONSE_FAILED:
        log_error("Sent RCR is FAILED to update at server\n");
        data.iot_state = IOT_STATE_RCR_READY_TO_SEND;
        // TODO: check here if want to exit in-between; just not to spent much time
        // check timout or cancel loop
        loop = true;
        break;
      default:
        log_error("Unhandled iot_state\n");
        break;
    }
  }

  return 0;
}

uint8_t data_deinit(void) {
  // store persistent items
  return 0;
}

void set_report_iot_msg_type(report_iot_msg_type_t msg_type) {
  data.report_iot_msg_type = msg_type;
}

uint8_t add_mold_data(time_t timestamp, uint32_t new_cycletime) {
  data_persisted.cycle_count++;
  data_persisted.cycle_time = new_cycletime;

  //## recalculate the sum of last n cycle times and update cycletime queue
  for (uint8_t i = 0; i < NLAST_CYCLETIMES_TOAVG_ARRSIZE; ++i) {
    if (data.conf_ptm_nlastcycletimes_toavg[i] == 0) {
      data_persisted.sum_lastn_cycletimes[i] = 0;
    } else if (data.conf_ptm_nlastcycletimes_toavg[i] == 1) {
      data_persisted.sum_lastn_cycletimes[i] = data_persisted.cycle_time;
    } else {
      int32_t old_cycletime = 0;

#if 0
      // fetch oldest cycle-time from queue only if queue is full
      if (isqueuefull(&data_persisted.cycletimecq) || (
            getqueuecount(&data_persisted.cycletimecq) >
            data.conf_ptm_nlastcycletimes_toavg[i])) {
        old_cycletime = *(uint32_t*)getqueuefront(&data_persisted.cycletimecq);
      }
#endif

      if (getqueuecount(&data_persisted.cycletimecq) ==
          (data.conf_ptm_nlastcycletimes_toavg[i] - 1)) {
        // set average window's front pointer
        data.queuefront_lastn_cycletimes[i] = getqueuefront(
            &data_persisted.cycletimecq);
      } else if (getqueuecount(&data_persisted.cycletimecq) >=
          data.conf_ptm_nlastcycletimes_toavg[i]) {
        // get oldest cycle time to discard
        old_cycletime = *(int32_t*)data.queuefront_lastn_cycletimes[i];

        // move average window's front pointer to next
        data.queuefront_lastn_cycletimes[i] = get_next_cqitemptr(
            &data_persisted.cycletimecq, data.queuefront_lastn_cycletimes[i]);
      }

      // update sum of last n cycle times accordingly
      data_persisted.sum_lastn_cycletimes[i] += ((int32_t)data_persisted.cycle_time -
          old_cycletime);
      log_debug("sum_lastn_cycletimes[%u] = %u\n", i, data_persisted.sum_lastn_cycletimes[i]);
    }
  }

  // enqueues new cycle item to overwrite front
  enqueue(&data_persisted.cycletimecq, &data_persisted.cycle_time);

  //## prepare rcr and enqueues the same
  rcr_t rcr = { 0 };

  // prepare rcr
  rcr.timestamp = timestamp;
  rcr.msg_type = data.report_iot_msg_type;
  rcr.msg_version = PTM_MSG_VERSION;
  rcr.cycle_count = data_persisted.cycle_count;

  for (uint8_t i = 0; i < NLAST_CYCLETIMES_TOAVG_ARRSIZE; ++i) {
    //err =
    get_avg_lastn_cycletimes(&rcr.avg_cycletimes[i], i);
  }

  // enqueues rcr
  enqueue(&data_persisted.rcrcq, &rcr);

  log_debug("mold-count = %u rcr-queue-count = %u\n",
      data_persisted.cycle_count,
      getqueuecount(&data_persisted.rcrcq));

  return 0;
}

void activate_ptm_transactions(void) {
  data.ptm_transactions_activated = true;
}

void iot_rcr_act_on_response(bool isaccepted) {
  if (data.iot_state == IOT_STATE_RCR_RESPONSE_WAITING) {
    if (isaccepted) {
      data.iot_state = IOT_STATE_RCR_RESPONSE_SUCCESS;
    } else {
      data.iot_state = IOT_STATE_RCR_RESPONSE_FAILED;
    }
  } else {
    log_fatal("Data module is not in correct state to perform action on RCR response");
  }
}
