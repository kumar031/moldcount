/*
 * timer.c
 */

#include "timer.h"
#include "logger.h"
#include <time.h>

// internal member definitions
static struct {
  uint32_t conf_ptm_sync_frequency;
  uint32_t conf_persist_sync_frequency;
  time_t ptm_sync_time;
  time_t persist_sync_time;
  uint8_t (*timer_event_callback)(timer_event_t event);
} timer = { 0 };

uint8_t timer_init(uint32_t conf_ptm_sync_frequency,
    uint32_t conf_persist_sync_frequency,
    uint8_t (*timer_event_callback)(timer_event_t event)) {
  time_t curr_time = 0;

  // local attribute initialization
  timer.conf_ptm_sync_frequency = conf_ptm_sync_frequency;
  timer.conf_persist_sync_frequency = conf_persist_sync_frequency;
  //timer.timer_event_callback = NULL;
  timer.timer_event_callback = timer_event_callback;

  curr_time = time(NULL);

  timer.ptm_sync_time = curr_time + timer.conf_ptm_sync_frequency;
  timer.persist_sync_time = curr_time + timer.conf_persist_sync_frequency;

  return 0;
}

uint8_t timer_loop(void) {
  uint8_t err = 0;
  timer_event_t timer_event = TIMER_EVENT_NONE;
  time_t curr_time = 0;

  // to skip unnecessarily call of logic;
  //   separate logic could also be implemented either here
  //   or before calling 'timer_loop()' at user's place

  curr_time = time(NULL);

  // TODO: handle if multiple i.e. 'TIMER_EVENT_*' events happened at same time

  if (curr_time >= timer.ptm_sync_time) {
    timer_event = TIMER_EVENT_PTM_FREQUENCY_TRIGGERED;
    timer.ptm_sync_time += timer.conf_ptm_sync_frequency;
  }

  if (curr_time >= timer.persist_sync_time) {
    timer_event = TIMER_EVENT_PERSIST_FREQUENCY_TRIGGERED;
    timer.persist_sync_time += timer.conf_persist_sync_frequency;
  }

  if (timer_event != TIMER_EVENT_NONE && timer.timer_event_callback) {
    err = timer.timer_event_callback(timer_event);
  }

  return err;
}

uint8_t timer_deinit(void) {
  return 0;
}
