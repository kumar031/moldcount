/*
 * logger.c
 */

#include "logger.h"

