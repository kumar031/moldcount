/*
 * json_ext.h
 */

#include "json_ext.h"
#include "consts.h"
#include "logger.h"
#include <string.h>
#include <stdlib.h>

uint8_t readjson_str(char * jsonstr, const char * querystr, char * p_out_str,
    size_t out_str_maxlen) {
  uint8_t err = 0;

  if (!(jsonstr && querystr && p_out_str && out_str_maxlen)) {
    log_error("bad parameters passed");
    err = 1;
  }

  // 'out_str_maxlen' should be 1 less then 'JSON_EXT_STR_VALUE_MAXLEN'
  // 1 byte is for null character
  if (!err && (out_str_maxlen >= JSON_EXT_STR_VALUE_MAXLEN)) {
    log_error("expected character string size is bigger then programically configured for querystr=%s\n",
        querystr);
    err = 2;
  }

  if (!err) {
    JSONStatus_t result = JSONSuccess;
    char * value = NULL;
    size_t value_len = 0;

    result = JSON_Search(jsonstr, strlen(jsonstr), querystr, strlen(querystr),
        &value, &value_len);

    if(result == JSONSuccess) {
      // copy value to provided location
      memcpy(p_out_str, value, value_len);
    }
  }

  return err;
}

uint8_t readjson_long(char * jsonstr, const char * querystr, long * p_out_long) {
  uint8_t err = 0;

  if (!(jsonstr && querystr && p_out_long)) {
    log_error("bad parameters passed");
    err = 1;
  }

  if (!err) {
    JSONStatus_t result = JSONSuccess;
    char * value = NULL;
    size_t value_len = 0;

    result = JSON_Search(jsonstr, strlen(jsonstr), querystr, strlen(querystr),
        &value, &value_len);

    if(result == JSONSuccess) {
      // copy value to provided location
      *p_out_long = strtol(value, NULL, 10);
    }
  }

  return err;
}
