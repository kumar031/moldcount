/*
 * cqueue.c
 */

#include "cqueue.h"
#include "logger.h"
#include <string.h>

uint8_t * get_next_cqitemptr(const cqueue_t * cqptr, const uint8_t * itemptr) {
  uint8_t * retptr = NULL;

  if (cqptr && itemptr) {
    const uint8_t * end_items_buf = cqptr->items_buf + (cqptr->max_itemcount *
        cqptr->itemsize);

    if (cqptr && (itemptr >= cqptr->items_buf) && (itemptr < end_items_buf)) {
      // increament itemptr by one item
      itemptr += cqptr->itemsize;

      // if itemptr is beyond right baundary of the buffer allocated for items
      // then relocate itemptr to the begin of the buffer
      if (itemptr >= end_items_buf) {
        itemptr = cqptr->items_buf;
      }
    }

    retptr = (uint8_t *)itemptr;
  }

  return retptr;
}

uint8_t initqueue(cqueue_t * cqptr, void * items_buf, uint32_t max_itemcount,
    size_t itemsize) {
  uint8_t err = 0;

  cqptr->front = cqptr->rear = NULL;
  cqptr->itemcount = 0;

  if (cqptr && items_buf && max_itemcount && itemsize) {
    cqptr->items_buf = items_buf;
    cqptr->max_itemcount = max_itemcount;
    cqptr->itemsize = itemsize;
  } else {
    cqptr->items_buf = NULL;
    cqptr->max_itemcount = 0;
    cqptr->itemsize = 0;

    log_error("initialization failed: wrong values passed for parameters\n");
    err = 1;
  }

  return err;
}

uint8_t enqueue(cqueue_t * cqptr, void * item) {
  uint8_t err = 0;

  if (cqptr && item) {
    // set rear to next valid location to have a new item there
    if (cqptr->rear == NULL) {
      // set rear and front at first item's location
      cqptr->front = cqptr->rear = cqptr->items_buf;
    } else {
      // locate rear at next possible location
      cqptr->rear = get_next_cqitemptr(cqptr, cqptr->rear);

      // rear's new location could overlap the front
      // so test and if overlaps then relocate front as well
      if (cqptr->rear == cqptr->front) {
        log_info("cqueue is full so discarding front\n");

        // relocate front to next
        cqptr->front = get_next_cqitemptr(cqptr, cqptr->front);
        // decrease item counter
        cqptr->itemcount--;
      }
    }

    // copy item at rear
    memcpy(cqptr->rear, item, cqptr->itemsize);
    // increase item counter
    cqptr->itemcount++;
  } else {
    err = 1;
    log_error("null queue or null item provided to add item to queue\n");
  }

  return err;
}

uint8_t dequeue(cqueue_t * cqptr, void * item) {
  uint8_t err = 0;

  if (cqptr) {
    if (cqptr->front) {
      if (item) {
        // copy item from front of queue to provided 'item' location
        memcpy(item, cqptr->front, cqptr->itemsize);
      } else {
        log_info("call with null 'item' provided is assumed that no copy is required before removing item from queue\n");
      }

      // set front to next valid item location or null
      if (cqptr->front == cqptr->rear) {
        cqptr->front = cqptr->rear = NULL;
      } else {
        // locate front at next possible location
        cqptr->front = get_next_cqitemptr(cqptr, cqptr->front);
      }

      // decrease item counter
      cqptr->itemcount--;
    } else {
      log_warning("tried to remove item from empty queue\n");
    }
  } else {
    err = 1;
    log_error("null queue provided to remove item from queue\n");
  }

  return err;
}

//bool isqueuefull(uint8_t * cqptr) {
//  return (cqptr && (cqptr->front == get_next_cqitemptr(cqptr, cqptr->rear)));
//}
