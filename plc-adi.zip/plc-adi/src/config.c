/*
 * config.c
 */

#include "config.h"
#include "logger.h"
#include "json_ext.h"
#include <string.h>
#include <errno.h>

uint8_t load_configurations(config_t * const config) {
  uint8_t err = 0;
  FILE * fp = NULL;

  if (!config) {
    log_error("Config structure is NULL\n");
    err = 1;
  }

  if (!err) {
    log_info("Reading configuration file %s\n", FS_CONFFILE_PATH);

    fp = fopen(FS_CONFFILE_PATH, "r");

    if(!fp) {
      log_error("File open error %d\n", errno);
      err = 2;
    }
  }

  char jsonbuf[FS_CONFFILE_MAXSIZE] = { 0 };
  size_t jsonbufsize = 0;

  if (!err) {
#if 0
    // get filesize
    long filesize = 0;

    err = fseek(fp, 0L, SEEK_END);
    if (!err) {
      filesize = ftell(fp);
      err = fseek(fp, 0L, SEEK_SET);
    }

    jsonbufsize = fread(json, filesize, 1, fp);
#endif

    jsonbufsize = fread(jsonbuf, 1, FS_CONFFILE_MAXSIZE, fp);

    if (ferror(fp)) {
      log_error("Error occured while reading configuration file\n");
      clearerr(fp);
      err = 3;
    } else if (jsonbufsize == FS_CONFFILE_MAXSIZE) {
      log_error("json file size is greater than allocated json buffer\n");
      err = 4;
    }
    //else if (feof(fp)) {
    //  log_info("json file successfully read into buffer\n");
    //}
  }

  if (!err) {
    JSONStatus_t result = JSONSuccess;

    result = JSON_Validate(jsonbuf, jsonbufsize);

    if(result == JSONSuccess) {
      memset(config, 0, sizeof(config_t));

      // make null terminated string
      jsonbuf[jsonbufsize] = '\0';

      // read configurations into config structure
      // read iot configurations
      err = readjson_str(jsonbuf, "IoT.Endpoint", config->iot.endpoint,
          sizeof(config->iot.endpoint));
      log_debug("iot_endpoint = %s\n", config->iot.endpoint);

      err = readjson_str(jsonbuf, "IoT.ShadowName", config->iot.shadow_name,
          sizeof(config->iot.shadow_name));
      log_debug("iot_topic = %s\n", config->iot.shadow_name);

      err = readjson_str(jsonbuf, "IoT.RootCAPath", config->iot.rootca_path,
          sizeof(config->iot.rootca_path));
      log_debug("iot_rootca_path = %s\n", config->iot.rootca_path);

      err = readjson_str(jsonbuf, "IoT.CertPath", config->iot.cert_path,
          sizeof(config->iot.cert_path));
      log_debug("iot_cert_path = %s\n", config->iot.cert_path);

      err = readjson_str(jsonbuf, "IoT.KeyPath", config->iot.key_path,
          sizeof(config->iot.key_path));
      log_debug("iot_key_path = %s\n", config->iot.key_path);

      // read ptm configurations
      err = readjson_uint32(jsonbuf, "PTM.SyncFrequency",
          &config->ptm.sync_frequency);
      log_debug("ptm_sync_frequency = %u\n", config->ptm.sync_frequency);

      // NOTE: Only single digit 'NLAST_CYCLETIMES_TOAVG_ARRSIZE' is supported for now
      char query[] = "PTM.LastCycleTimesCountToAvg[i]";
      for (uint8_t i = 0; (!err && (i < NLAST_CYCLETIMES_TOAVG_ARRSIZE)); ++i) {
        query[(sizeof(query) - 3)] = '0' + i;

        err = readjson_uint32(jsonbuf, query,
            &config->ptm.nlastcycletimes_toavg[i]);
        log_debug("ptm_nlastcycletimes_toavg[%u] = %u\n", i, config->ptm.nlastcycletimes_toavg[i]);
      }

      // read persist configurations
      err = readjson_uint32(jsonbuf, "Persist.SyncFrequency",
          &config->persist.sync_frequency);
      log_debug("persist_sync_frequency = %u\n", config->persist.sync_frequency);

      //err = readjson_str(jsonbuf, "Persist.RcrCqPath",
      //    config->persist.rcr_cq_path, sizeof(config->persist.rcr_cq_path));
      //log_debug("persist_rcr_cq_path = %s\n", config->persist.rcr_cq_path);

      //err = readjson_str(jsonbuf, "Persist.CycleTimeCqPath",
      //    config->persist.cycletime_cq_path,
      //    sizeof(config->persist.cycletime_cq_path));
      //log_debug("persist_cycletime_cq_path = %s\n", config->persist.cycletime_cq_path);
    }
  }

  if(fp) {
    fclose(fp);
  }

  return err;
}

//uint8_t save_configurations(config_t * const config) {
//  return 0;
//}
