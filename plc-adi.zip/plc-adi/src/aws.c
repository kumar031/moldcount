/*
 * aws.c
 */

#include "aws.h"
#include "logger.h"
#include "consts.h"
#include "core_mqtt.h"
#include "openssl_posix.h"
#include "backoff_algorithm.h"
#include "clock.h"
#include "shadow.h"

/*-----------------------------------------------------------*/

#define MQTT_LIB    "core-mqtt@" MQTT_LIBRARY_VERSION

/**
 * ALPN protocol name for AWS IoT MQTT.
 *
 * This will be used if the AWS_MQTT_PORT is configured as 443 for AWS IoT MQTT broker.
 * Please see more details about the ALPN protocol for AWS IoT MQTT endpoint
 * in the link below.
 * https://aws.amazon.com/blogs/iot/mqtt-with-tls-client-authentication-on-port-443-why-it-is-useful-and-how-it-works/
 *
 * OpenSSL requires that the protocol string passed to it for configuration be encoded
 * with the prefix of 8-bit length information of the string. Thus, the 14 byte (0x0e) length
 * information is prefixed to the string.
 */
#define ALPN_PROTOCOL_NAME           "\x0ex-amzn-mqtt-ca"

/**
 * @brief Length of ALPN protocol name.
 */
#define ALPN_PROTOCOL_NAME_LENGTH    (sizeof(ALPN_PROTOCOL_NAME) - 1)

/*-----------------------------------------------------------*/

struct NetworkContext {
  OpensslParams_t * pParams;
};

// internal member definitions
static struct {
  NetworkContext_t networkContext;  // network context used for Openssl operation
  MQTTContext_t mqttContext;        // MQTT context used for MQTT operation
  OpensslParams_t opensslParams;    // parameters for Openssl operation
  uint8_t network_buffer[NETWORK_BUFFER_SIZE];  // network buffer must remain valid for the lifetime of the MQTT context
  struct {
    uint16_t packetId;              // Packet identifier of the publish packet
    MQTTPublishInfo_t pubInfo;      // Publish info of the publish packet
  } outgoingPublishPackets[MAX_OUTGOING_PUBLISHES]; // Array to keep the outgoing publish messages until a successful ack is received
  bool mqttSessionEstablished;      // flag to indicate the mqtt session changed

  uint8_t (*aws_event_callback)(aws_event_t event);
} aws = { 0 };

/*-----------------------------------------------------------*/

/**
 * Function to clean up all the outgoing publishes maintained in the array.
 */
static inline void cleanupOutgoingPublishes(void) {
  /* Clean up all the outgoing publish packets. */
  memset(aws.outgoingPublishPackets, 0x00, sizeof(aws.outgoingPublishPackets));
}

/**
 * Function to clean up an outgoing publish at given index from the
 * 'outgoingPublishPackets' array.
 */
static inline uint8_t cleanupOutgoingPublishAt(uint8_t index) {
  uint8_t err = 0;

  if (index >= MAX_OUTGOING_PUBLISHES) {
    log_error("invalid index passed\n");
    err = 1;
  } else {
    /* Clear the outgoing publish packet. */
    memset(&aws.outgoingPublishPackets[index], 0x00,
        sizeof(aws.outgoingPublishPackets[index]));
  }

  return err;
}

/**
 * Function to clean up the publish packet with the given packet id.
 */
static inline uint8_t cleanupOutgoingPublishWithPacketID(uint16_t packetId) {
  uint8_t err = 0;

  if (packetId != MQTT_PACKET_ID_INVALID) {
    /* Clean up all the saved outgoing publishes. */
    for (uint8_t index = 0; index < MAX_OUTGOING_PUBLISHES; index++) {
      if (aws.outgoingPublishPackets[index].packetId == packetId) {
        cleanupOutgoingPublishAt(index);
        log_info("Cleaned up outgoing publish packet with packet id %u.", packetId);
        break;
      }
    }
  } else {
    log_error("invalid packetId to cleanup from aws.outgoingPublishPackets\n");
    err = 1;
  }

  return err;
}

/**
 * Connect to MQTT broker with reconnection retries.
 * If connection fails, retry is attempted after a timeout.
 * Timeout value will exponentially increase until maximum
 * timeout value is reached or the number of attempts are exhausted.
 */
static inline uint8_t connectToServerWithBackoffRetries(const char * endpoint,
    const char * rootca_path, const char * cert_path, const char * key_path) {
  uint8_t err = 0;
  ServerInfo_t serverInfo;
  OpensslCredentials_t opensslCredentials;
  OpensslStatus_t opensslStatus = OPENSSL_SUCCESS;
  BackoffAlgorithmStatus_t backoffAlgStatus = BackoffAlgorithmSuccess;
  BackoffAlgorithmContext_t reconnectParams;
  uint16_t nextRetryBackOff = 0U;
  struct timespec tp;

  /* Set the pParams member of the network context with desired transport. */
  aws.networkContext.pParams = &aws.opensslParams;

  /* Initialize information to connect to the MQTT broker. */
  serverInfo.pHostName = endpoint;
  serverInfo.hostNameLength = strlen(endpoint);
  serverInfo.port = AWS_MQTT_PORT;

  /* Initialize credentials for establishing TLS session. */
  memset(&opensslCredentials, 0, sizeof(OpensslCredentials_t));
  opensslCredentials.pRootCaPath = rootca_path;
  opensslCredentials.pClientCertPath = cert_path;
  opensslCredentials.pPrivateKeyPath = key_path;
  opensslCredentials.sniHostName = endpoint;

  if(AWS_MQTT_PORT == 443) {
    /* Pass the ALPN protocol name depending on the port being used.
     * Please see more details about the ALPN protocol for AWS IoT MQTT endpoint
     * in the link below.
     * https://aws.amazon.com/blogs/iot/mqtt-with-tls-client-authentication-on-port-443-why-it-is-useful-and-how-it-works/
     */
    opensslCredentials.pAlpnProtos = ALPN_PROTOCOL_NAME;
    opensslCredentials.alpnProtosLen = ALPN_PROTOCOL_NAME_LENGTH;
  } else {
    log_warning("verify logic as port protocol ignored\n");
  }

  /* Seed pseudo random number generator used in the demo for
   * backoff period calculation when retrying failed network operations
   * with broker. */

  /* Get current time to seed pseudo random number generator. */
  clock_gettime(CLOCK_REALTIME, &tp);
  /* Seed pseudo random number generator with nanoseconds. */
  srand(tp.tv_nsec);

  /* Initialize reconnect attempts and interval */
  BackoffAlgorithm_InitializeParams(&reconnectParams,
      CONNECTION_RETRY_BACKOFF_BASE_MS, CONNECTION_RETRY_MAX_BACKOFF_DELAY_MS,
      CONNECTION_RETRY_MAX_ATTEMPTS);

  /* Attempt to connect to MQTT broker. If connection fails, retry after
   * a timeout. Timeout value will exponentially increase until maximum
   * attempts are reached.
   */
  do
  {
    /* Establish a TLS session with the MQTT broker.  */
    log_info("Establishing a TLS session to %s:%d\n", endpoint,
        AWS_MQTT_PORT);

    opensslStatus = Openssl_Connect(&aws.networkContext, &serverInfo,
        &opensslCredentials, TRANSPORT_SEND_RECV_TIMEOUT_MS,
        TRANSPORT_SEND_RECV_TIMEOUT_MS);

    if(opensslStatus != OPENSSL_SUCCESS) {
      /* Generate a random number and get back-off value (in milliseconds) for
       * the next connection retry. */
      backoffAlgStatus = BackoffAlgorithm_GetNextBackoff(&reconnectParams,
          rand(), &nextRetryBackOff);

      if(backoffAlgStatus == BackoffAlgorithmSuccess) {
        log_warning("Connection to the broker failed. Retrying connection after %hu ms backoff\n",
            nextRetryBackOff);
        Clock_SleepMs(nextRetryBackOff);
      } else if(backoffAlgStatus == BackoffAlgorithmRetriesExhausted) {
        log_error("Connection to the broker failed, all attempts exhausted\n");
        err = 1;
      }
      else {
        log_error("Unknown Backoff Algorithm Status");
        err = 2;
      }
    }
  } while((!err) && (opensslStatus != OPENSSL_SUCCESS));

  return err;
}

/**
 * Function to resend the publishes if a session is re-established with
 * the broker. This function handles the resending of the QoS1 publish packets,
 * which are maintained locally.
 */
static inline uint8_t handlePublishResend(void) {
  uint8_t err = 0;
  MQTTStatus_t mqttStatus = MQTTSuccess;

  /* Resend all the QoS1 publishes still in the array. These are the
   * publishes that hasn't received a PUBACK. When a PUBACK is
   * received, the publish is removed from the array. */
  for(uint8_t index = 0U; index < MAX_OUTGOING_PUBLISHES; index++) {
    if(aws.outgoingPublishPackets[index].packetId != MQTT_PACKET_ID_INVALID) {
      aws.outgoingPublishPackets[index].pubInfo.dup = true;

      log_info("Sending duplicate PUBLISH with packet id %u\n",
          aws.outgoingPublishPackets[index].packetId);

      mqttStatus = MQTT_Publish(&aws.mqttContext,
          &aws.outgoingPublishPackets[index].pubInfo,
          aws.outgoingPublishPackets[index].packetId);

      if(mqttStatus != MQTTSuccess) {
        log_error("Sending duplicate PUBLISH for packet id %u failed with status %u\n",
            aws.outgoingPublishPackets[index].packetId, mqttStatus);
        err = 1;
        break;
      } else {
        log_info("Sent duplicate PUBLISH successfully for packet id %u\n",
            aws.outgoingPublishPackets[index].packetId);

        //err = aws_loop();
        //if (err) {
        //  log_warning("");
        //  err = 4;
        //}
      }
    } else {
      log_error("Invalid packetId exists in outgoing publish \n");
    }
  }

  return err;
}

/**
 * Function to get the free index at which an outgoing publish can be stored.
 */
static inline uint8_t getNextFreeIndexForOutgoingPublishes(uint8_t * pIndex) {
  uint8_t err = 0;

  if (!pIndex) {
    log_error("null is passed as index location\n");
    err = 1;
  } else {
    for(uint8_t index = 0; index < MAX_OUTGOING_PUBLISHES; index++) {
      /* A free index is marked by invalid packet id.
       * Check if the the index has a free slot. */
      if(aws.outgoingPublishPackets[index].packetId == MQTT_PACKET_ID_INVALID) {
        /* Copy the available index into the output param. */
        *pIndex = index;
        break;
      }
    }
  }

  return err;
}

/*-----------------------------------------------------------*/

static inline uint8_t HandleShadowIncomingPacket(MQTTPublishInfo_t * pPublishInfo) {
  uint8_t err = 0;
  ShadowMessageType_t messageType = ShadowMessageTypeMaxNum;
  const char * pThingName = NULL;
  uint8_t thingNameLength = 0U;
  const char * pShadowName = NULL;
  uint8_t shadowNameLength = 0U;

  if (!pPublishInfo) {
    log_error("Deserialized publish info not found\n");
    err = 1;
  } else {
    log_info("pPublishInfo->pTopicName:%.*s.", pPublishInfo->topicNameLength,
        pPublishInfo->pTopicName);

    /* test whether this is a device shadow message */
    if (SHADOW_SUCCESS == Shadow_MatchTopicString(pPublishInfo->pTopicName,
          pPublishInfo->topicNameLength, &messageType, &pThingName,
          &thingNameLength, &pShadowName, &shadowNameLength)) {
      /* Upon successful return, the messageType has been filled in. */
      switch(messageType) {
        case ShadowMessageTypeGetAccepted:
          log_info("Received an MQTT incoming publish on /get/accepted topic\n");
          break;

        case ShadowMessageTypeGetRejected:
          log_info("Received an MQTT incoming publish on /get/rejected topic\n");
          break;

        case ShadowMessageTypeUpdateDelta:
          log_info("Received an MQTT incoming publish on /update/delta topic\n");
          break;

        case ShadowMessageTypeUpdateAccepted:
          log_info("Received an MQTT incoming publish on /update/accepted topic\n");
          //updateAcceptedHandler(pPublishInfo);
          aws.aws_event_callback(AWS_EVENT_IOT_RCR_RESPONSE_ACCEPTED);
          break;

        case ShadowMessageTypeUpdateDocuments:
          log_info("Received an MQTT incoming publish on /update/documents topic\n");
          //log_info("/update/documents json payload:%.*s\n",
          //    pPublishInfo->payloadLength, pPublishInfo->pPayload);
          break;

        case ShadowMessageTypeUpdateRejected:
          log_info("Received an MQTT incoming publish on /update/rejected topic\n");
          //log_info("/update/documents json payload:%.*s\n",
          //    pPublishInfo->payloadLength, pPublishInfo->pPayload);
          aws.aws_event_callback(AWS_EVENT_IOT_RCR_RESPONSE_REJECTED);
          break;

        case ShadowMessageTypeDeleteAccepted:
          log_info("Received an MQTT incoming publish on /delete/accepted topic\n");
          break;

        case ShadowMessageTypeDeleteRejected:
          log_info("Received an MQTT incoming publish on /delete/rejected topic\n");
          break;

        default:
          log_info("Other message type:%d !!\n", messageType);
          break;
      }
    } else {
      log_fatal("Shadow_MatchTopicString parse failed:%.*s !!\n",
          pPublishInfo->topicNameLength, pPublishInfo->pTopicName);
      err = 2;
    }
  }

  return err;
}

static inline uint8_t HandleOtherIncomingPacket(MQTTPacketInfo_t * pPacketInfo,
    uint16_t packetIdentifier) {
  uint8_t err = 0;

  /* Handle other packets. */
  switch (pPacketInfo->type) {
    case MQTT_PACKET_TYPE_SUBACK:
      log_info("MQTT_PACKET_TYPE_SUBACK packet id %u\n", packetIdentifier);
      /* Make sure ACK packet identifier matches with Request packet identifier. */
      //assert(globalSubscribePacketIdentifier == packetIdentifier);
      break;

    case MQTT_PACKET_TYPE_UNSUBACK:
      log_info("MQTT_PACKET_TYPE_UNSUBACK packet id %u\n", packetIdentifier);
      /* Make sure ACK packet identifier matches with Request packet identifier. */
      //assert(globalUnsubscribePacketIdentifier == packetIdentifier);
      break;

    case MQTT_PACKET_TYPE_PINGRESP:
      /* Nothing to be done from application as library handles PINGRESP. */
      log_warning("PINGRESP should not be handled by the application callback when using MQTT_ProcessLoop\n");
      break;

    case MQTT_PACKET_TYPE_PUBACK:
      log_info("PUBACK received for packet id %u\n", packetIdentifier);
      /* Cleanup publish packet when a PUBACK is received. */
      cleanupOutgoingPublishWithPacketID(packetIdentifier);
      break;

    default:
      /* Any other packet type is invalid. */
      log_error("Unknown packet type received:(%02x)\n", pPacketInfo->type);
  }

  return err;
}

/* This is the callback function invoked by the MQTT stack when it receives
 * incoming messages.
 */
/*
//eventCallback:
//  MQTT_PACKET_TYPE_PUBLISH
//    Shadow_MatchTopicString
//    ShadowMessageTypeUpdateDelta
//    ShadowMessageTypeUpdateAccepted
//    ShadowMessageTypeUpdateDocuments
//    ShadowMessageTypeUpdateRejected
//    ShadowMessageTypeDeleteAccepted
//    ShadowMessageTypeDeleteRejected
//  HandleOtherIncomingPacket
//    MQTT_PACKET_TYPE_SUBACK
//    MQTT_PACKET_TYPE_UNSUBACK
//    MQTT_PACKET_TYPE_PINGRESP
//    MQTT_PACKET_TYPE_PUBACK
//      cleanupOutgoingPublishWithPacketID
*/
static void mqttEventCallback(MQTTContext_t * pMqttContext,
    MQTTPacketInfo_t * pPacketInfo, MQTTDeserializedInfo_t * pDeserializedInfo) {
  uint8_t err = 0;

  uint16_t packetIdentifier = 0U;

  if (!(pMqttContext && pPacketInfo && pDeserializedInfo)) {
    log_error("mqttEventCallback called with wrong parameters\n");
  } else {
    packetIdentifier = pDeserializedInfo->packetIdentifier;

    /* Handle incoming publish. The lower 4 bits of the publish packet
     * type is used for the dup, QoS, and retain flags. Hence masking
     * out the lower bits to check if the packet is publish. */
    if ((pPacketInfo->type & 0xF0U) == MQTT_PACKET_TYPE_PUBLISH) {
      err = HandleShadowIncomingPacket(pDeserializedInfo->pPublishInfo);
    } else {
      err = HandleOtherIncomingPacket(pPacketInfo, packetIdentifier);
    }
  }

  if (err) {
    log_error("Error occured in mqtt event callback handling\n");
  }
}

/*-----------------------------------------------------------*/

/*
//EstablishMqttSession
//  connectToServerWithBackoffRetries
//    BackoffAlgorithm_InitializeParams
//    Openssl_Connect
//    BackoffAlgorithm_GetNextBackoff
//  MQTT_Init
//  MQTT_Connect
//  if-sesson:
//    handlePublishResend
//      MQTT_Publish
//  else:
//    cleanupOutgoingPublishes
//
//subscribe_to_topic
*/
uint8_t aws_init(uint8_t (*aws_event_callback)(aws_event_t event),
    const char * endpoint, const char * rootca_path, const char * cert_path,
    const char * key_path) {
  uint8_t err = 0;
  bool sessionPresent = false;

  // local attribute initialization
  aws.aws_event_callback = aws_event_callback;

  aws.mqttSessionEstablished = false;

  err = connectToServerWithBackoffRetries(endpoint, rootca_path, cert_path, key_path);

  if (err) {
    log_fatal("Failed to connect to MQTT broker %s\n", endpoint);
    err = 1;
  } else {
    TransportInterface_t transport = { 0 };
    MQTTConnectInfo_t connectInfo = { 0 };
    MQTTFixedBuffer_t networkBuffer = { 0 };
    MQTTStatus_t mqttStatus = MQTTSuccess;

    /* Fill in TransportInterface send and receive function pointers.
     * TCP sockets are used to send and receive data from network
     * Network context is SSL context for OpenSSL. */
    transport.pNetworkContext = &aws.networkContext;
    transport.send = Openssl_Send;
    transport.recv = Openssl_Recv;

    /* Fill the values for network buffer. */
    networkBuffer.pBuffer = aws.network_buffer;
    networkBuffer.size = NETWORK_BUFFER_SIZE;

    /* Initialize MQTT library. */
    mqttStatus = MQTT_Init(&aws.mqttContext, &transport, Clock_GetTimeMs,
        mqttEventCallback, &networkBuffer);

    if(mqttStatus != MQTTSuccess) {
      log_error("MQTT init failed with status %u\n", mqttStatus);
      err = 2;
    } else {
      /* Establish MQTT session by sending a CONNECT packet. */

      /* If 'cleanSession' is true, start with a clean session
       * i.e. direct the MQTT broker to discard any previous session data.
       * If 'cleanSession' is false, directs the broker to attempt to
       * reestablish a session which was already present. */
      connectInfo.cleanSession = false;

      /* The client identifier is used to uniquely identify this MQTT client to
       * the MQTT broker. In a production device the identifier can be something
       * unique, such as a device serial number. */
      connectInfo.pClientIdentifier = DEVICE_IDENTIFIER;
      connectInfo.clientIdentifierLength = strlen(DEVICE_IDENTIFIER);

      /* The maximum time interval in seconds which is allowed to elapse
       * between two Control Packets.
       * It is the responsibility of the Client to ensure that the interval between
       * Control Packets being sent does not exceed the this Keep Alive value. In the
       * absence of sending any other Control Packets, the Client MUST send a
       * PINGREQ Packet. */
      connectInfo.keepAliveSeconds = MQTT_KEEP_ALIVE_INTERVAL_SECONDS;

#if 0
      /* Username and password for authentication. Not used in this demo. */
      connectInfo.pUserName = METRICS_STRING;
      connectInfo.userNameLength = METRICS_STRING_LENGTH;
      connectInfo.pPassword = NULL;
      connectInfo.passwordLength = 0U;
#endif

      /* Send MQTT CONNECT packet to broker. */
      mqttStatus = MQTT_Connect(&aws.mqttContext, &connectInfo, NULL,
          CONNACK_RECV_TIMEOUT_MS, &sessionPresent);

      if(mqttStatus != MQTTSuccess) {
        log_error("Connection with MQTT broker failed with status %u\n", mqttStatus);
        err = 3;
      } else {
        log_info("MQTT connection successfully established with broker\n");

        /* Keep a flag for indicating if MQTT session is established. This
         * flag will mark that an MQTT DISCONNECT has to be sent at the end
         * even if there are intermediate failures. */
        aws.mqttSessionEstablished = true;

        /* Check if session is present and if there are any outgoing publishes
         * that need to resend. This is only valid if the broker is
         * re-establishing a session which was already present. */
#if 0
        if(sessionPresent) {
          log_info("An MQTT session with broker is re-established. Resending unacked publishes\n");

          /* Handle all the resend of publish messages. */
          err = handlePublishResend();
        } else {
          log_info("A clean MQTT connection is established. Cleaning up all the stored outgoing publishes\n");

          /* Clean up the outgoing publishes waiting for ack as this new
           * connection doesn't re-establish an existing session. */
          cleanupOutgoingPublishes();
        }
#endif
      }
    }
  }

  return err;
}

/*
//MQTT_ProcessLoop
*/
uint8_t aws_loop(void) {
  uint8_t err = 0;
  MQTTStatus_t mqttStatus = MQTTSuccess;

  /* MQTT_ProcessLoop processes incoming publishes.
   * This function also sends ping request to broker if
   * MQTT_KEEP_ALIVE_INTERVAL_SECONDS has expired since the last
   * MQTT packet sent and receive ping responses. */
  mqttStatus = MQTT_ProcessLoop(&aws.mqttContext, MQTT_PROCESS_LOOP_TIMEOUT_MS);

  if(mqttStatus != MQTTSuccess) {
    log_error("MQTT_ProcessLoop returned with status = %u\n", mqttStatus);
    err = 1;
  }

  return err;
}

/*
//if subscribed:
//  unsubscribe_from_topic
//DisconnectMqttSession
//  MQTT_Disconnect
//  Openssl_Disconnect
*/
uint8_t aws_deinit(void) {
  uint8_t err = 0;
  MQTTStatus_t mqttStatus = MQTTSuccess;

  //if subscribed:
  //  unsubscribe from subscribed topics

  if(aws.mqttSessionEstablished) {
    aws.mqttSessionEstablished = false;
    /* Send DISCONNECT. */
    mqttStatus = MQTT_Disconnect(&aws.mqttContext);

    if(mqttStatus != MQTTSuccess) {
      log_error("Sending MQTT DISCONNECT failed with status=%u.", mqttStatus);
      err = 1;
    }
  }

  /* End TLS session, then close TCP connection. */
  Openssl_Disconnect(&aws.networkContext);

  return err;
}

/*
//PublishToTopic
//  getNextFreeIndexForOutgoingPublishes
//  MQTT_GetPacketId
//  MQTT_Publish
//  MQTT_ProcessLoop
*/
uint8_t publish_to_topic(const char * topic, const uint8_t * payload,
    size_t payload_len) {
  uint8_t err = 0;
  MQTTStatus_t mqttStatus = MQTTSuccess;
  uint8_t publishIndex = MAX_OUTGOING_PUBLISHES;

  if (!(topic && *topic && payload && payload_len)) {
    log_error("invalid parameters passed to publish\n");
    err = 1;
  } else {
    /* Get the next free index for the outgoing publish. All QoS1 outgoing
     * publishes are stored until a PUBACK is received. These messages are
     * stored for supporting a resend if a network connection is broken before
     * receiving a PUBACK. */
    err = getNextFreeIndexForOutgoingPublishes(&publishIndex);

    if (err) {
      log_error("Unable to find a free spot for outgoing PUBLISH message\n");
      err = 2;
    } else {
      log_info("Published payload: %s", payload);

      aws.outgoingPublishPackets[publishIndex].pubInfo.qos = MQTTQoS1;
      aws.outgoingPublishPackets[publishIndex].pubInfo.pTopicName = topic;
      aws.outgoingPublishPackets[publishIndex].pubInfo.topicNameLength = strlen(topic);
      aws.outgoingPublishPackets[publishIndex].pubInfo.pPayload = payload;
      aws.outgoingPublishPackets[publishIndex].pubInfo.payloadLength = payload_len;

      /* Get a new packet id. */
      aws.outgoingPublishPackets[publishIndex].packetId = MQTT_GetPacketId(&aws.mqttContext);

      /* Send PUBLISH packet. */
      mqttStatus = MQTT_Publish(&aws.mqttContext,
          &aws.outgoingPublishPackets[publishIndex].pubInfo,
          aws.outgoingPublishPackets[publishIndex].packetId);

      if (mqttStatus != MQTTSuccess) {
        log_error("Failed to send PUBLISH packet to broker with error = %u\n",
            mqttStatus);
        cleanupOutgoingPublishAt(publishIndex);
        err = 3;
      } else {
        log_info("PUBLISH sent for topic %s to broker with packet ID %u\n",
            topic, aws.outgoingPublishPackets[publishIndex].packetId);

        //err = aws_loop();
        //if (err) {
        //  log_warning("");
        //  err = 4;
        //}
      }
    }
  }

  return err;
}

/*
//SubscribeToTopic
//  MQTT_GetPacketId
//  MQTT_Subscribe
//  MQTT_ProcessLoop
*/
uint8_t subscribe_to_topic(const char * topic) {
  uint8_t err = 0;
  MQTTStatus_t mqttStatus;
  MQTTSubscribeInfo_t subInfo = { 0 };

  if (!topic && *topic) {
    log_error("topic not found to unsubscribe from\n");
    err = 1;
  } else {
    subInfo.qos = MQTTQoS1;
    subInfo.pTopicFilter = topic;
    subInfo.topicFilterLength = strlen(topic);

    /* Generate packet identifier for the SUBSCRIBE packet. */
    uint16_t globalSubscribePacketIdentifier = MQTT_GetPacketId(&aws.mqttContext);

    /* Send SUBSCRIBE packet. */
    mqttStatus = MQTT_Subscribe(&aws.mqttContext, &subInfo, 1,
        globalSubscribePacketIdentifier);

    if(mqttStatus != MQTTSuccess) {
      log_error("Failed to send SUBSCRIBE packet to broker with error = %u\n",
          mqttStatus);
      err = 2;
    } else {
      log_info("SUBSCRIBE sent for topic %s to broker\n", topic);

      //err = aws_loop();
    }
  }


  return err;
}

/*
//UnsubscribeFromTopic
//  MQTT_GetPacketId
//  MQTT_Unsubscribe
//  MQTT_ProcessLoop
*/
uint8_t unsubscribe_from_topic(const char * topic) {
  uint8_t err = 0;
  MQTTStatus_t mqttStatus;
  MQTTSubscribeInfo_t subInfo = { 0 };

  if (!topic && *topic) {
    log_error("topic not found to unsubscribe from\n");
    err = 1;
  } else {
    subInfo.qos = MQTTQoS1;
    subInfo.pTopicFilter = topic;
    subInfo.topicFilterLength = strlen(topic);

    /* Generate packet identifier for the UNSUBSCRIBE packet. */
    uint16_t globalUnsubscribePacketIdentifier = MQTT_GetPacketId(&aws.mqttContext);

    /* Send UNSUBSCRIBE packet. */
    mqttStatus = MQTT_Unsubscribe(&aws.mqttContext, &subInfo, 1,
        globalUnsubscribePacketIdentifier);

    if(mqttStatus != MQTTSuccess) {
      log_error("Failed to send UNSUBSCRIBE packet to broker with error = %u\n",
          mqttStatus);
      err = 2;
    } else {
      log_info("UNSUBSCRIBE sent for topic %s to broker\n", topic);

      //err = aws_loop();
    }
  }

  return err;
}

#if 0
uint8_t subscribe_shadow(const char * thing_name, const char * shadow_name) {
  uint8_t err = 0;
  char topic_update_accepted[IOT_TOPIC_MAXLEN] = "";
  char topic_update_rejected[IOT_TOPIC_MAXLEN] = "";
  uint16_t topic_len = 0;
  ShadowStatus_t shadowStatus = SHADOW_SUCCESS;

  if (!(thing_name && *thing_name && shadow_name && *shadow_name)) {
    log_error("thing-name or shadow-name cannot be null or empty\n");
    err = 1;
  }

  if (!err) {
    shadowStatus = Shadow_AssembleTopicString(ShadowMessageTypeUpdateAccepted,
        thing_name, strlen(thing_name), shadow_name, strlen(shadow_name),
        topic_update_accepted, sizeof(topic_update_accepted), &topic_len);

    if (shadowStatus != SHADOW_SUCCESS) {
      log_error("Unable to assemble 'update/accepted' type topic string for shadow '%s' of thing '%s'\n",
          shadow_name, thing_name);
      err = 2;
    } else {
      topic_update_accepted[topic_len] = '\0';

      err = subscribe_to_topic(topic_update_accepted);
    }
  }

  if (!err) {
    shadowStatus = Shadow_AssembleTopicString(ShadowMessageTypeUpdateRejected,
        thing_name, strlen(thing_name), shadow_name, strlen(shadow_name),
        topic_update_rejected, sizeof(topic_update_rejected), &topic_len);

    if (shadowStatus != SHADOW_SUCCESS) {
      log_error("Unable to assemble 'update/rejected' type topic string for shadow '%s' of thing '%s'\n",
          shadow_name, thing_name);
      err = 2;
    } else {
      topic_update_rejected[topic_len] = '\0';

      err = subscribe_to_topic(topic_update_rejected);

      if(err) {
        log_debug("Unsubscribing from subscribed topic '%s'\n", topic_update_accepted);
        unsubscribe_from_topic(topic_update_accepted);
      }
    }
  }

  return err;
}
#endif
